type SectionTitleProps = {
	children: string;
};

export function SectionTitle({ children }: SectionTitleProps) {
	return <h2 className='text-3xl'>{children}</h2>;
}
