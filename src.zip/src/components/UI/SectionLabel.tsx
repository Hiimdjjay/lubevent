import { PulsingDot } from './PulsingDot';

type SectionLabelProps = {
	children: React.ReactNode;
	pulsingDot?: boolean;
	bgColor?: string;
};

export function SectionLabel({
	children,
	pulsingDot = false,
	bgColor = 'bg-white/70'
}: SectionLabelProps) {
	return (
		<div
			className={`flex flex-row w-fit items-center gap-2 py-2 px-4 rounded-full ${bgColor}`}>
			{pulsingDot && <PulsingDot />}
			<p className="text-sm text-black/60">{children}</p>
		</div>
	);
}
