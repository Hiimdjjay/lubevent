import { SectionLabel } from '@/components/UI/SectionLabel';
import { SectionTitle } from '@/components/UI/SectionTitle';

export function AboutUs() {
	return (
		<section className='p-4 py-20'>
			<div className='flex flex-col items-start'>
				<SectionLabel>O nas</SectionLabel>
				<SectionTitle>Tworzymy zespół doświadczonych specjalistów</SectionTitle>
			</div>
			<div></div>
		</section>
	);
}
