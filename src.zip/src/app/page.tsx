import { AboutUs } from '@/components/Sections/AboutUs/AboutUs';
import { Hero } from '@/components/Sections/Hero/Hero';

export default function Home() {
	return (
		<main>
			<Hero />
			<AboutUs />
		</main>
	);
}
